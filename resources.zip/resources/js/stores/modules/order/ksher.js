export default {
    namespaced: true,
    state: {
        useKsherChannelPayment: {},
        ksherPay: [],
    },
    mutations: {
        useKsherChannelPayment(state, data) {
            state.useKsherChannelPayment = data;
        },
        ksherPay(state, data) {
            state.ksherPay = data;
        },
    },
    getters: {
        useKsherChannelPayment: (state) => state.useKsherChannelPayment,
        ksherPay: (state) => state.ksherPay,
        kshers: (state) => state.kshers,
    },
    actions: {
        async getUseKsherChannelPayment({ commit }) {
            const res = await axios.get(
                `/api/v1/guest/ksher/getUseKsherChannelPayment`
            );
            commit("useKsherChannelPayment", res.data);
        },
        async createKsherPay({ commit }, payload) {
            const res = await axios.post(
                `/api/v1/guest/ksher/orderCreate`,
                payload
            );
            commit("ksherPay", res.data);
            return res.data;
        },
        async orderQuery({}, payload) {
            const res = await axios.get(
                `/api/admin/v1/ksher/${payload.mch_order_no}/orderQuery`
            );
            return res;
        },
        async checkStatusPaid({}, payload) {
            return await axios
                .get(
                    `/api/v1/guest/ksher/${payload.mch_order_no}/checkStatusPaid`
                )
                .then((response) => {
                    return response;
                })
                .catch((err) => {
                    log.error(err);
                });
        },

        async fetch({ commit }, payload) {
            const params = payload.params ? payload.params : "";
            return await axios
                .get(`/api/admin/v1/ksher/fetch?${params}`)
                .then((response) => {
                    commit("ksherPay", response.data);
                    return response;
                })
                .catch((err) => {
                    log.error(err);
                });
        },

        async setDayOff({}, payload) {
            return await axios
                .post(`/api/admin/v1/ksher/setDayOff`, payload)
                .then((response) => {
                    return response;
                })
                .catch((err) => {
                    log.error(err);
                });
        },
    },
};
