export default {
    namespaced: true,
    state: {
        text: {
            order: {
                number:"หมายเลขคำสั่งซื้อ",
                
            }
        }
    },
    mutations: {},
    getters: {
        text: state => state.text,
    },
    actions: {}
};

