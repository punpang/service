<template>
  <div>
      
  </div>
</template>

<script>
export default {
  data() {
    return {
      // url: this.$route.query.mch_order_no,
    };
  },
};
</script>