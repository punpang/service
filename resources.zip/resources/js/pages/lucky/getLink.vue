<template>
  <div>
    <h1>HEllo Get Link</h1>
  </div>
</template>
<script>
export default {};
</script>