@extends('layouts.main')
@section('body')

    <div class="card">
      <div class="card-head">
        s
      </div>
      <div class="card-body">
fsd
      </div>
    </div>

@endsection
