<?php

namespace App\Http\Controllers\Punpang;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PriceController extends Controller
{
    //
}
