<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UsersTableSeeder::class,
            ChannelOfPurchasesTableSeeder::class,
            OrderStatusTableSeeder::class,
            LinesKeyTableSeeder::class,
            CustomerTableSeeder::class,
            ProductCategorySubTableSeed::class,
            ProductCategoryTableSeed::class,
            ProductTableSeed::class,
            OrderPaymentMethodTableSeed::class,
            SlipVerifyTableSeed::class,
            SlipUnVerifyReasoningTableSeed::class,            
        ]);
    }
}
