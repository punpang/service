<template>
  <div class="about">
    <h1>Test Auth</h1>

  </div>
</template>

<script>

export default {
  components:{
    Menu
  },
  data(){
    return {
    }
  }
}
</script>
