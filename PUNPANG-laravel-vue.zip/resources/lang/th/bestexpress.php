<?php

return [

  'sender' => [
    'name' => 'ชื่อผู้ส่ง : :name',
    'number' => 'เบอร์โทร : :number',
    'address' => 'ที่อยู่ : :address',
  ],
  'recipient' => [

  ],

  'table' => [
    ''
  ],
  'choose' => [
    'recipient' => [
      'name' => 'ชื่อผู้รับ',
      'number' => 'เบอร์ผู้รับ',
      'waybill' => 'เลขพัสดุ',
      'placeholder' => [
        'name' => 'กรอกชื่อของผู้รับ',
        'number' => 'กรอกเบอร์โทรของผู้รับ',
        'waybill' => 'กรอกเลขพัสดุของผู้รับ'
      ]
    ],
  ]

];

?>
