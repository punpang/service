<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UsersTableSeeder::class,
            UserTypeSeeder::class,
            MenuBarSeeder::class,
            ImageSeeder::class,
            PromotionProductSeeder::class,
            PromotionSeeder::class,
            OrderStatusSeeder::class,
            PaymentStatusSeeder::class,
        ]);
    }
}
