<template>
    <div>   
        <v-alert type="error">ไม่มีหน้าเว็ปไซต์นี้</v-alert>     
    </div>
</template>

<script>
export default {};
</script>

<style></style>
