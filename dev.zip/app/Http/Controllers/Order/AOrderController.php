<?php

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Order\AOrder;
use App\Linenotify;
use App\MSms;

class AOrderController extends Controller
{
    public function sumOrderToday()
    {
        return AOrder::where([
            ["date_get", now()->format("Y-m-d")],
            ["status", "9"]
        ])->count();
    }

    public function waitConfirmFromCustomer()
    {
        $orders = AOrder::where([
            ["date_get", now()->addDays(1)->format("Y-m-d")],
            ["status", 2]
        ])->get();

        $msgLine = "รายการพรุ่งนี้ รอชำระเงิน " . $orders->count() . " รายการ";
        Linenotify::send($msgLine);

        foreach ($orders as $order) {
            $date_get = \Carbon\Carbon::parse($order->date_get)->addYears(543)->format("d-m-Y");
            $msgLine = "แจ้งชำระเงิน -> #" . $order->id . " รับ " . $date_get . " " . $order->time_get . " น.";
            $msgSms = "ปั้นแป้ง สวัสดีค่ะ [อัตโนมัติ] โปรดชำระมัดจำ เลขคำสั่งซื้อ #" . $order->id . " รับ " . $date_get . " " . $order->time_get . " น. ของคุณ เพื่อยืนยันการสั่งซื้อ และรับสินค้าได้ตามเวลานัดที่ท่านแจ้งไว้ โปรดชำระก่อน 14.00 น.";
            Linenotify::send($msgLine);
            MSms::Sms($order->customer->tel, $msgSms);
        }

        return "success";
    }

    public function orderToDay()
    {
        $waitConfirm = AOrder::where([
            ["date_get", now()->format("Y-m-d")],
            ["status", 2]
        ])->count();

        $confirm = AOrder::where("date_get", now()->format("Y-m-d"))
            ->whereIn("status", [3, 4, 5])->count();

        $msgLine = "สั่งซื้อสำเร็จ ( " . $confirm . " ) | รอยืนยัน ( " . $waitConfirm . " )";
        Linenotify::send($msgLine);

        return "success";
    }

    public function sumDaily()
    {
        $orders = AOrder::where([
            ["date_get", now()->format("Y-m-d")],
            ["status", 9]
        ])->get();

        $msgLine = "ยอดขายวันนี้ โดยประมาณ ฿" . number_format($orders->sum("total"), 2)  . " จากทั้งหมด " . $orders->count() . " รายการ";
        Linenotify::send($msgLine);

        return "success";
    }

    public function sumWeekly()
    {
        $toDay = now()->format("Y-m-d");
        $fromDay = now()->subDays(6)->format("Y-m-d");

        $orders = AOrder::whereBetween("date_get", [$fromDay, $toDay])
            ->where("status", 9)
            ->get();

        $msgLine = "ยอดขายประจำสัปดาห์ (" . now()->subDays(6)->format("d") . " - " . now()->format("d-m-Y") . ") ฿" . number_format($orders->sum("total"), 2) . " ( " . $orders->count() . " รายการ )";
        Linenotify::send($msgLine);

        return "success";
    }

    public function sumMonthly()
    {
        $month = now()->subMonths(1)->format("m");
        $year = now()->format("Y");

        $orders = AOrder::whereMonth("date_get", $month)
            ->whereYear("date_get", $year)
            ->where("status", 9)
            ->get();

        $msgLine = "ยอดขายประจำเดือน " . $month . " ฿" . number_format($orders->sum("total"), 2) . " ( " . $orders->count() . " รายการ )";
        Linenotify::send($msgLine);

        return "success";
    }

    public function sumAnnual()
    {
        $year = now()->subYears(1)->format("Y");

        $orders = AOrder::whereYear("date_get", $year)
            ->where("status", 9)
            ->get();

        $msgLine = "ยอดขายประจำปี " . $year . " ฿" . number_format($orders->sum("total"), 2) . " ( " . $orders->count() . " รายการ )";
        Linenotify::send($msgLine);

        return "success";
    }
}
