<?php

namespace App\Http\Controllers\Momday;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class timeGetGoodController extends Controller
{
    //
}
