<?php

namespace App;

use App\ShabuNooNee\DiningTable;
use App\ShabuNoonee\UserType;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Tymon\JWTAuth\Contracts\JWTSubject;


class User extends Authenticatable implements JWTSubject
{
    use Notifiable;
    const DEFAULT_TYPE = 0;
    const ADMIN_TYPE = 1;
    const CASHIER_TYPE = 2;
    const WAITRESS_TYPE = 3;
    const KITCHEN_TYPE = 4;
    const CUSTOMER_TYPE = 5;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function isAdmin()
    {
        return $this->type === self::ADMIN_TYPE;
    }

    public function isCashier()
    {
        return $this->type === self::CASHIER_TYPE;
    }

    public function isCustomer()
    {
        return $this->type === self::CUSTOMER_TYPE;
    }

    public function isKitchen()
    {
        return $this->type === self::KITCHEN_TYPE;
    }

    public function isWaitress()
    {
        return $this->type === self::WAITRESS_TYPE;
    }


    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function userType()
    {
        return $this->belongsTo(UserType::class, "type", "id");
    }

    public function table()
    {
        return $this->hasOne(DiningTable::class, "user_id", "id")->whereIn("status_id", [1, 2, 3]);
    }
}
