<?php

namespace App\Momday;

use Illuminate\Database\Eloquent\Model;

class timeGetGood extends Model
{
    //
}
