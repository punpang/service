<?php

namespace App\Momday;

use Illuminate\Database\Eloquent\Model;

class PaymentStatus extends Model
{
    //
}
