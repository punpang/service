<?php

namespace App\Order;

use Illuminate\Database\Eloquent\Model;

class ACustomer extends Model
{
    protected $table = "a_customer";

    protected $connection = 'order';

    public function getDateGetAtAttribute($date)
    {
        return \Carbon\Carbon::createFromFormat('Y-m-d', $date)->addYears(543)->format('d-m-Y');
    }
}
