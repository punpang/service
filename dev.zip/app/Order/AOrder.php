<?php

namespace App\Order;

use Illuminate\Database\Eloquent\Model;

class AOrder extends Model
{
    protected $table = "a_order";

    protected $connection = 'order';

    public function customer()
    {
        return $this->belongsTo(ACustomer::class, "id_customer", "id");
    }
}
