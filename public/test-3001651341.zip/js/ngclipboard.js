var myApp = angular.module('myApp', ['ngclipboard']);
