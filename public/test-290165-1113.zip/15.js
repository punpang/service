(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[15],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      data: {}
    };
  },
  methods: {
    start: function start() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        var loader, datas;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                loader = _this.$loading.show();
                _context.next = 3;
                return _this.$store.dispatch("orderGuestUuid/getByUUID", {
                  uuid: _this.$route.params.uuid
                });

              case 3:
                datas = _context.sent;
                _this.data = datas.data;
                loader.hide();

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _this2.start(); // await axios.get(`/api/${this.$route.params.id}/test`);


            case 1:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-card",
        { staticClass: "mb-2" },
        [
          _c("v-card-title", [
            _c("h4", { staticClass: "mb-0" }, [_vm._v("สรุปรายการสั่งซื้อ")]),
          ]),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-2" },
        [
          _c("v-card-title", [
            _c("h5", { staticClass: "mb-0" }, [_vm._v("ข้อมูลลูกค้า")]),
          ]),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c("v-simple-table", [
                _c("tbody", [
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("ชื่อ")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.customer.name))]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("เบอร์โทร")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.customer.tel))]),
                    ]),
                  ]),
                ]),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-2" },
        [
          _c("v-card-title", [
            _c("h5", { staticClass: "mb-0" }, [_vm._v("ข้อมูลรายการสั่งซื้อ")]),
          ]),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c("v-simple-table", [
                _c("tbody", [
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("หมายเลขคำสั่งซื้อ")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.id))]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("วัน-เวลารับสินค้า")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [
                        _vm._v(
                          _vm._s(_vm.data.date_get) +
                            " " +
                            _vm._s(_vm.data.time_get)
                        ),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("วัน-เวลาที่สั่งซื้อ")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.date_order))]),
                    ]),
                  ]),
                ]),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-2" },
        [
          _c("v-card-title", [
            _c("h5", { staticClass: "mb-0" }, [_vm._v("ข้อมูลสินค้า")]),
          ]),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c("v-simple-table", [
                _c("tbody", [
                  _vm.data.m1 !== 99 ||
                  _vm.data.m2 !== 99 ||
                  _vm.data.m3 !== 99 ||
                  _vm.data.m4 !== 99
                    ? _c("tr", [
                        _c("td", { attrs: { colspan: "2" } }, [
                          _c("strong", [
                            _vm._v(
                              _vm._s(_vm.data.am1.m1) +
                                " : " +
                                _vm._s(_vm.data.am2.m2) +
                                " : " +
                                _vm._s(_vm.data.am3.m3) +
                                " :\n                " +
                                _vm._s(_vm.data.am4.m4) +
                                "\n              "
                            ),
                          ]),
                        ]),
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.data.code !== "-"
                    ? _c("tr", [
                        _c("td", [_c("strong", [_vm._v("ข้อมูลเพิ่มเติม")])]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c("strong", [
                            _vm._v(
                              "\n                " +
                                _vm._s(_vm.data.code) +
                                "\n              "
                            ),
                          ]),
                        ]),
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.data.msg !== "-"
                    ? _c("tr", [
                        _c("td", [_c("strong", [_vm._v("เขียนข้อความ")])]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c("strong", [_vm._v(_vm._s(_vm.data.msg))]),
                        ]),
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.data.other !== "-"
                    ? _c("tr", [
                        _c("td", [_c("strong", [_vm._v("หมายเหตุ")])]),
                        _vm._v(" "),
                        _c("td", { staticClass: "text-right" }, [
                          _c("strong", [_vm._v(_vm._s(_vm.data.other))]),
                        ]),
                      ])
                    : _vm._e(),
                ]),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card",
        { staticClass: "mb-2" },
        [
          _c("v-card-title", [
            _c("h5", { staticClass: "mb-0" }, [_vm._v("ข้อมูลชำระเงิน")]),
          ]),
          _vm._v(" "),
          _c(
            "v-card-text",
            [
              _c("v-simple-table", [
                _c("tbody", [
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("ยอดทั้งหมด")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [
                        _vm._v(_vm._s(_vm.data.total + _vm.data.add)),
                      ]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("ยอดชำระแล้ว")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.deposit))]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("ยอดคงเหลือ")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.balance))]),
                    ]),
                  ]),
                  _vm._v(" "),
                  _c("tr", [
                    _c("td", [_c("strong", [_vm._v("สถานะ")])]),
                    _vm._v(" "),
                    _c("td", { staticClass: "text-right" }, [
                      _c("strong", [_vm._v(_vm._s(_vm.data.a_status.status))]),
                    ]),
                  ]),
                ]),
              ]),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/pages/guest/orders/uuid.vue":
/*!**************************************************!*\
  !*** ./resources/js/pages/guest/orders/uuid.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./uuid.vue?vue&type=template&id=78aab1d5& */ "./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5&");
/* harmony import */ var _uuid_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./uuid.vue?vue&type=script&lang=js& */ "./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _uuid_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__["render"],
  _uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/guest/orders/uuid.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_uuid_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./uuid.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/guest/orders/uuid.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_uuid_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5&":
/*!*********************************************************************************!*\
  !*** ./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5& ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./uuid.vue?vue&type=template&id=78aab1d5& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/guest/orders/uuid.vue?vue&type=template&id=78aab1d5&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_uuid_vue_vue_type_template_id_78aab1d5___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);